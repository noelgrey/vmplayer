jQuery(document).ready(function() {
 
            $('.pause').hide();
            
            $('.play').click(function() {
            $('.play').hide();
            $('.pause').show();
            swap();
            });
            
            $('.pause').click(function() {
            $('.play').show();
            $('.pause').hide();
            swap();
            });
            }); 
        
jQuery(document).ready(function() {
            $('.pause').hide();
            
            $('.playlist').click(function() {
            $('.play').hide();
            $('.pause').show();
            swap();
            });
            
            $('.playlist').click(function() {
            $('.play').show();
            $('.pause').hide();
            swap();
            });
            }); 
            
jQuery(document).ready(function() {
            $('.pause').hide();
            
            $('.fwd').click(function() {
            $('.play').hide();
            $('.pause').show();
            swap();
            });
            
            $('.fwd').click(function() {
            $('.play').show();
            $('.pause').hide();
            swap();
            });
            }); 
            
jQuery(document).ready(function() {
            $('.pause').hide();
            
            $('.rew').click(function() {
            $('.play').hide();
            $('.pause').show();
            swap();
            });
            
            $('.rew').click(function() {
            $('.play').show();
            $('.pause').hide();
            swap();
            });
            }); 
            
